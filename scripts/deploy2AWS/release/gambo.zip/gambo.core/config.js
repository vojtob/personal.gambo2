var config = {};

config.region = "eu-central-1";
config.endpoint = "https://dynamodb.eu-central-1.amazonaws.com";

module.exports = config;